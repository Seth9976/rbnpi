//Analog clock with figures based on example on Processing Site, and various on YouTube
//adjusted by Robin Newman
//add SansSerif-18.vlw from Tools->Create Font...   (smooth)
int cx, cy;
float secondsRadius;
float minutesRadius;
float hoursRadius;
float clockDiameter;

void setup() {
  size(400,400);
  stroke(255);
PFont font = loadFont("SansSerif-18.vlw");
textFont(font);
textAlign(CENTER,CENTER);
  float radius = min(width/1.2, height/1.2) / 2;
  secondsRadius = radius * 0.72;
  minutesRadius = radius * 0.60;
  hoursRadius = radius * 0.50;
  clockDiameter = radius * 1.8;

  cx = width / 2;
  cy = height / 2;
}

void draw() {
   background(20,20,255); //adjust as desired
  // Draw the clock background
  fill(0);
  noStroke();
  ellipse(cx, cy, clockDiameter, clockDiameter);

  // Angles for sin() and cos() start at 3 o'clock;
  // subtract HALF_PI to make them start at the top
  float s = map(second(), 0, 60, 0, TWO_PI) - HALF_PI;
  float m = map(minute() + norm(second(), 0, 60), 0, 60, 0, TWO_PI) - HALF_PI; 
  float h = map(hour() + norm(minute(), 0, 60), 0, 24, 0, TWO_PI * 2) - HALF_PI;

  // Draw the hands of the clock
  stroke(255);
  strokeWeight(1);
  line(cx, cy, cx + cos(s) * secondsRadius, cy + sin(s) * secondsRadius);
  strokeWeight(2);
  line(cx, cy, cx + cos(m) * minutesRadius, cy + sin(m) * minutesRadius);
  strokeWeight(4);
  line(cx, cy, cx + cos(h) * hoursRadius, cy + sin(h) * hoursRadius);

  // Draw the dots arround the clock
  strokeWeight(2);
  beginShape(POINTS);
  for (int a = 0; a < 360; a+=6) {
    float angle = radians(a);
    float x = cx + cos(angle) * secondsRadius;
    float y = cy + sin(angle) * secondsRadius;
 if( a%30 !=0){ //miss out point if numerical position for hour
    vertex(x, y);}
  }
  endShape();
  int hour = 3;
  for (int a = 0; a < 360; a+=30) {
    float angle = radians(a);
    float x = cx + cos(angle) * secondsRadius;
    float y = cy + sin(angle) * secondsRadius;

    vertex(x, y); //add point to show minite position on face
    fill(255);


    //text(hour, x, y);
    textSize(18);
    text(Integer.toString(hour),x,y);
    hour++;
    if(hour > 12){
      hour = 1;
    }
  }
  textSize(22);
    text("Sonic Pi Musical Talking Clock", width/2,20);
    text("Clock Face by Processing Script", width/2,height-30);
}